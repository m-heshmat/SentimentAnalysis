# 🧠 Real-Time Multilingual Sentiment Analysis (Arabic & English)
